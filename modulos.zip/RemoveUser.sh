#!/bin/bash

nome_usuario="${1:-}"

if [[ -z "$nome_usuario" || "$nome_usuario" = "root" || "$nome_usuario" = "nobody" || ! "$nome_usuario" =~ ^[A-Za-z0-9_.-]{1,64}$ ]]; then
    echo "erro"
    exit 1
fi

pkill -u "$nome_usuario" >/dev/null 2>&1

userdel -f "$nome_usuario" >/dev/null 2>&1

[ ! -f /root/usuarios.db ] && touch /root/usuarios.db
tmp_db=$(mktemp)
awk -v user="$nome_usuario" '$1 != user {print}' /root/usuarios.db > "$tmp_db" && mv "$tmp_db" /root/usuarios.db

rm -f /etc/SSHPlus/senha/"$nome_usuario" >/dev/null 2>&1
rm -f /etc/usuarios/"$nome_usuario" >/dev/null 2>&1
rm -f /etc/TesteAtlas/"$nome_usuario.sh" >/dev/null 2>&1

pkill -u "$nome_usuario" >/dev/null 2>&1

echo "sucesso"
