#!/usr/bin/env python3
import sys
import os
import subprocess
import crypt
from datetime import datetime, timedelta

usuario = sys.argv[1]
senha   = sys.argv[2]
dias    = int(sys.argv[3])
limite  = sys.argv[4]

# soma +1 dia ao prazo de expiração
exp      = (datetime.now() + timedelta(days=dias+1)).strftime("%Y-%m-%d")
hash_pwd = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))

# remove usuário existente antes de recriar
subprocess.run(
    ["bash", "/opt/darkapi/RemoveUser.sh", usuario],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

# cria usuário com senha e expiração
subprocess.run([
    "useradd", "-M", "-s", "/bin/false",
    "-p", hash_pwd, "-e", exp, usuario
], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# salva senha em arquivo
os.makedirs("/etc/SSHPlus/senha/", exist_ok=True)
with open(f"/etc/SSHPlus/senha/{usuario}", "w") as f:
    f.write(senha)

# adiciona no banco de usuários
def append_linha_limpa(caminho, linha_nova):
    linhas_limpas = []
    if os.path.exists(caminho):
        with open(caminho, "r", encoding="utf-8") as f:
            linhas_limpas = [l.strip() for l in f if l.strip()]
    linhas_limpas.append(linha_nova)
    with open(caminho, "w", encoding="utf-8") as f:
        f.write("\n".join(linhas_limpas) + "\n")

append_linha_limpa("/root/usuarios.db", f"{usuario} {limite}")

print("sucesso")
