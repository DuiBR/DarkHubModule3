#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sincronizar.py - sincronização defensiva compatível com o módulo antigo.
Formato do arquivo: login senha dias limite [uuid]
- dias <= 0 não sincroniza;
- entradas inválidas são ignoradas e registradas;
- evita execução simultânea com lock;
- mantém a lógica original: AddUser.py para SSH e AddSincV2.py para V2Ray/Xray.
"""
import fcntl
import json
import logging
import os
import re
import subprocess
import sys
import traceback
from pathlib import Path

BASE_DIR = Path('/opt/darkapi')
LOG_FILE = BASE_DIR / 'sincronizar.log'
LOCK_FILE = BASE_DIR / 'sincronizar.lock'
MAX_LOG_SIZE = 3 * 1024 * 1024
PYTHON_PATH = sys.executable or '/usr/bin/python3'
ADD_USER = BASE_DIR / 'AddUser.py'
ADD_V2 = BASE_DIR / 'AddSincV2.py'
V2RAY_CONFIG = Path('/etc/v2ray/config.json')
XRAY_CONFIG = Path('/usr/local/etc/xray/config.json')
LOGIN_RE = re.compile(r'^[A-Za-z0-9_.-]{1,64}$')
UUID_RE = re.compile(r'^[a-fA-F0-9]{8}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{12}$')


def rotate_log():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    if LOG_FILE.exists() and LOG_FILE.stat().st_size > MAX_LOG_SIZE:
        LOG_FILE.unlink()


def setup_logger():
    rotate_log()
    logging.basicConfig(filename=str(LOG_FILE), level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', force=True)


def log(msg, level='info'):
    getattr(logging, level.lower(), logging.info)(msg)


def safe_file(path: Path) -> bool:
    try:
        real = path.resolve()
        allowed = [BASE_DIR.resolve(), (BASE_DIR / 'sync_incoming').resolve(), Path('/tmp').resolve()]
        return any(str(real).startswith(str(root) + os.sep) or real == root for root in allowed)
    except Exception:
        return False


def parse_int(value, minimum, maximum):
    try:
        n = int(str(value).strip())
    except Exception:
        return None
    return n if minimum <= n <= maximum else None


def parse_line(line, line_no):
    col = line.split()
    if len(col) < 4:
        return None, f'linha {line_no}: colunas insuficientes'
    login, senha, dias_raw, limite_raw = col[0], col[1], col[2], col[3]
    uuid = col[4].strip() if len(col) >= 5 else ''
    if not LOGIN_RE.match(login):
        return None, f'linha {line_no}: login inválido ({login})'
    if not senha or re.search(r'[\x00-\x20]', senha) or len(senha) > 128:
        return None, f'linha {line_no}: senha inválida para {login}'
    dias = parse_int(dias_raw, 1, 3650)
    if dias is None:
        return None, f'linha {line_no}: usuário {login} ignorado por validade expirada/inválida (dias={dias_raw})'
    limite = parse_int(limite_raw, 1, 100000)
    if limite is None:
        return None, f'linha {line_no}: limite inválido para {login}'
    if uuid and not UUID_RE.match(uuid):
        return None, f'linha {line_no}: UUID inválido para {login}'
    return {'login': login, 'senha': senha, 'dias': str(dias), 'limite': str(limite), 'uuid': uuid}, ''


def load_users(sync_file: Path):
    users = {}
    stats = {'lidas': 0, 'validas': 0, 'ignoradas': 0, 'duplicadas': 0}
    with sync_file.open('r', encoding='utf-8', errors='ignore') as f:
        for line_no, raw in enumerate(f, 1):
            line = raw.strip()
            if not line:
                continue
            stats['lidas'] += 1
            user, reason = parse_line(line, line_no)
            if not user:
                stats['ignoradas'] += 1
                log('Ignorado: ' + reason, 'warning')
                continue
            login = user['login']
            if login in users:
                stats['duplicadas'] += 1
                if int(user['dias']) < int(users[login]['dias']):
                    continue
            users[login] = user
    stats['validas'] = len(users)
    return list(users.values()), stats


def run(cmd, label):
    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120, check=False)
        if result.returncode == 0:
            log(f'✔️ {label} concluído')
            return True
        log(f'❌ {label} falhou codigo={result.returncode} stderr={(result.stderr or "")[:300]}', 'error')
        return False
    except Exception as e:
        log(f'❌ {label} erro: {e}', 'error')
        return False


def dedupe_clients(path: Path, xray=False):
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        changed = False
        if xray:
            for inbound in data.get('inbounds', []):
                if inbound.get('tag') != 'inbound-sshplus':
                    continue
                clients = inbound.get('settings', {}).get('clients', [])
                new, seen_ids, seen_emails = [], set(), set()
                for c in clients:
                    cid, email = c.get('id'), c.get('email')
                    if (cid and cid in seen_ids) or (email and email in seen_emails):
                        changed = True
                        continue
                    if cid: seen_ids.add(cid)
                    if email: seen_emails.add(email)
                    new.append(c)
                inbound.setdefault('settings', {})['clients'] = new
        else:
            inbounds = data.get('inbounds', [])
            if inbounds:
                clients = inbounds[0].get('settings', {}).get('clients', [])
                new, seen_ids, seen_emails = [], set(), set()
                for c in clients:
                    cid, email = c.get('id'), c.get('email')
                    if (cid and cid in seen_ids) or (email and email in seen_emails):
                        changed = True
                        continue
                    if cid: seen_ids.add(cid)
                    if email: seen_emails.add(email)
                    new.append(c)
                inbounds[0].setdefault('settings', {})['clients'] = new
        if changed:
            path.write_text(json.dumps(data, indent=2), encoding='utf-8')
            os.chmod(path, 0o644)
        return changed
    except Exception as e:
        log(f'Erro ao limpar duplicatas em {path}: {e}', 'error')
        return False


def restart_services():
    dedupe_clients(V2RAY_CONFIG, False)
    dedupe_clients(XRAY_CONFIG, True)
    for service, cfg in {'v2ray': V2RAY_CONFIG, 'xray': XRAY_CONFIG}.items():
        if not cfg.exists():
            continue
        try:
            active = subprocess.run(['systemctl', 'is-active', '--quiet', service]).returncode == 0
            subprocess.run(['systemctl', 'restart' if active else 'start', service], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
            log(f'Serviço {service} validado/reiniciado')
        except Exception as e:
            log(f'Erro ao reiniciar {service}: {e}', 'error')


def main():
    setup_logger()
    log('==== INÍCIO SINCRONIZAR ====')
    if len(sys.argv) < 2:
        print('error')
        return 1
    sync_file = Path(sys.argv[1])
    if not sync_file.exists() or not safe_file(sync_file):
        log(f'Arquivo inválido/não permitido: {sync_file}', 'error')
        print('error')
        return 1
    with LOCK_FILE.open('w') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            log('Outra sincronização em execução; encerrando.', 'warning')
            print('error')
            return 1
        try:
            users, stats = load_users(sync_file)
            log(f'Estatísticas: {stats}')
            if not users:
                sync_file.unlink(missing_ok=True)
                print('error')
                return 1
            ok = 0
            fail = 0
            for u in users:
                if u['uuid']:
                    if not ADD_V2.exists():
                        log(f'{ADD_V2} não encontrado', 'error')
                        fail += 1
                        continue
                    cmd = [PYTHON_PATH, str(ADD_V2), u['uuid'], u['login'], u['senha'], u['dias'], u['limite']]
                    label = f'AddSincV2({u["login"]})'
                else:
                    if not ADD_USER.exists():
                        log(f'{ADD_USER} não encontrado', 'error')
                        fail += 1
                        continue
                    cmd = [PYTHON_PATH, str(ADD_USER), u['login'], u['senha'], u['dias'], u['limite']]
                    label = f'AddUser({u["login"]})'
                if run(cmd, label): ok += 1
                else: fail += 1
            sync_file.unlink(missing_ok=True)
            restart_services()
            log(f'==== FIM SINCRONIZAR ok={ok} falhas={fail} ====')
            print('comandoenviadocomsucesso')
            return 0 if ok > 0 else 1
        except Exception as e:
            log(f'Erro geral: {e}\n{traceback.format_exc()}', 'error')
            try: sync_file.unlink(missing_ok=True)
            except Exception: pass
            print('error')
            return 1

if __name__ == '__main__':
    sys.exit(main())
