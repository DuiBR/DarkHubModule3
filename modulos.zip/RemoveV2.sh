#!/bin/bash
set -u

arg1="${1:-}"
arg2="${2:-}"
config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"

is_uuid() {
    [[ "$1" =~ ^[0-9a-fA-F]{8}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{4}-?[0-9a-fA-F]{12}$ ]]
}

# Compatibilidade: versões antigas chamavam em ordens diferentes.
# Aceita tanto: RemoveV2.sh <uuid> <usuario> quanto RemoveV2.sh <usuario> <uuid>
if is_uuid "$arg1"; then
    uuid_remover="$arg1"
    nome_usuario="$arg2"
else
    nome_usuario="$arg1"
    uuid_remover="$arg2"
fi

if [ -z "$nome_usuario" ] || [ "$nome_usuario" = "root" ]; then
    echo "erro"
    exit 1
fi

limpar_v2ray() {
    local arquivo="$1"
    [ -f "$arquivo" ] || return 0
    local tmp
    tmp=$(mktemp)
    jq --arg uuid "$uuid_remover" --arg email "$nome_usuario" '
        if (.inbounds[0].settings.clients? // null) then
            .inbounds[0].settings.clients |= map(select((.id // "") != $uuid and (.email // "") != $email))
        else . end
    ' "$arquivo" > "$tmp" 2>/dev/null && mv "$tmp" "$arquivo" || rm -f "$tmp"
    chmod 644 "$arquivo" >/dev/null 2>&1 || true
}

limpar_xray() {
    local arquivo="$1"
    [ -f "$arquivo" ] || return 0
    local tmp
    tmp=$(mktemp)
    jq --arg uuid "$uuid_remover" --arg email "$nome_usuario" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients? // null) then
                .settings.clients |= map(select((.id // "") != $uuid and (.email // "") != $email))
            else . end
        )
    ' "$arquivo" > "$tmp" 2>/dev/null && mv "$tmp" "$arquivo" || rm -f "$tmp"
    chmod 644 "$arquivo" >/dev/null 2>&1 || true
}

limpar_v2ray "$config_v2ray"
limpar_xray "$config_xray"

if systemctl is-active --quiet v2ray; then
    systemctl restart v2ray >/dev/null 2>&1 || true
elif [ -f "$config_v2ray" ]; then
    systemctl start v2ray >/dev/null 2>&1 || true
fi

if systemctl is-active --quiet xray; then
    systemctl restart xray >/dev/null 2>&1 || true
elif [ -f "$config_xray" ]; then
    systemctl start xray >/dev/null 2>&1 || true
fi

bash /opt/darkapi/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1 || true

echo "sucesso"
