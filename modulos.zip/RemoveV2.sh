#!/bin/bash

uuid_remover="$1"
nome_usuario="$2"

config_v2ray="/etc/v2ray/config.json"
config_xray="/usr/local/etc/xray/config.json"

if [ -f "$config_v2ray" ]; then
    temp_v2ray=$(mktemp)
    jq --arg uuid "$uuid_remover" '
        .inbounds[0].settings.clients |= map(select(.id != $uuid))
    ' "$config_v2ray" > "$temp_v2ray" 2>/dev/null && mv "$temp_v2ray" "$config_v2ray"
    chmod 777 "$config_v2ray" >/dev/null 2>&1
fi

if [ -f "$config_xray" ]; then
    temp_xray=$(mktemp)
    jq --arg uuid "$uuid_remover" '
        .inbounds |= map(
            if .tag == "inbound-sshplus" and (.settings.clients // null)
            then .settings.clients |= map(select(.id != $uuid))
            else .
            end
        )
    ' "$config_xray" > "$temp_xray" 2>/dev/null && mv "$temp_xray" "$config_xray"
    chmod 777 "$config_xray" >/dev/null 2>&1
fi

if systemctl is-active --quiet v2ray; then
    systemctl restart v2ray >/dev/null 2>&1
elif [ -f "$config_v2ray" ]; then
    systemctl start v2ray >/dev/null 2>&1
fi

if systemctl is-active --quiet xray; then
    systemctl restart xray >/dev/null 2>&1
elif [ -f "$config_xray" ]; then
    systemctl start xray >/dev/null 2>&1
fi

bash /opt/darkapi/RemoveUser.sh "$nome_usuario" >/dev/null 2>&1

echo "sucesso"
