#!/usr/bin/env python3
import sys
import os
import subprocess
import crypt
import json
from datetime import datetime, timedelta

uuid_usuario = sys.argv[1]
nome_usuario = sys.argv[2]
senha = sys.argv[3]
dias = int(sys.argv[4])
limite = sys.argv[5]

config_v2ray = "/etc/v2ray/config.json"
config_xray = "/usr/local/etc/xray/config.json"
senha_path = f"/etc/SSHPlus/senha/{nome_usuario}"
novo_cliente = {"email": nome_usuario, "id": uuid_usuario, "level": 0}

def update_json(path, update_fn):
    """Carrega, aplica modificações e salva JSON"""
    try:
        with open(path, 'r') as f:
            data = json.load(f)
    except Exception:
        return False
    modified = update_fn(data)
    if not modified:
        return False
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)
    os.chmod(path, 0o777)
    return True

# Atualiza cliente no V2Ray
if os.path.isfile(config_v2ray):
    def fn_v2(data):
        inbounds = data.get('inbounds', [])
        if not inbounds:
            return False
        clients = inbounds[0].get('settings', {}).get('clients', [])
        filtered = [c for c in clients if c.get('email') != nome_usuario]
        inbounds[0]['settings']['clients'] = [novo_cliente] + filtered
        return True
    update_json(config_v2ray, fn_v2)

# Atualiza cliente no XRay
if os.path.isfile(config_xray):
    def fn_xray(data):
        changed = False
        for ib in data.get('inbounds', []):
            if ib.get('tag') == 'inbound-sshplus':
                clients = ib.get('settings', {}).get('clients', [])
                filtered = [c for c in clients if c.get('email') != nome_usuario]
                ib['settings']['clients'] = [novo_cliente] + filtered
                changed = True
        return changed
    update_json(config_xray, fn_xray)

# Expiração (+dias)
exp = (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")

# Hash de senha
hash_pwd = crypt.crypt(senha, crypt.mksalt(crypt.METHOD_MD5))

# Garante que o usuário exista (se não, cria)
if subprocess.call(["id", nome_usuario], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) != 0:
    subprocess.run([
        "useradd", "-M", "-s", "/bin/false", nome_usuario
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

# Atualiza senha
subprocess.run(
    ["usermod", "-p", hash_pwd, nome_usuario],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

# Atualiza expiração
subprocess.run(
    ["chage", "-E", exp, nome_usuario],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)

# Salva senha no arquivo
os.makedirs(os.path.dirname(senha_path), exist_ok=True)
with open(senha_path, "w") as f:
    f.write(senha)

# Atualiza usuarios.db (sem duplicar)
usuarios_db = "/root/usuarios.db"
def atualizar_usuario(path, usuario, limite):
    linhas = []
    if os.path.isfile(path):
        with open(path, 'r') as f:
            for l in f:
                if not l.strip():
                    continue
                if not l.startswith(usuario + " "):
                    linhas.append(l.strip())
    linhas.append(f"{usuario} {limite}")
    with open(path, 'w') as f:
        f.write("\n".join(linhas) + "\n")

atualizar_usuario(usuarios_db, nome_usuario, limite)

print("sucesso")
