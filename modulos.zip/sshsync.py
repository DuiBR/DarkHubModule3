#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sshsync.py - sincronização defensiva de usuários ativos do painel com a VPS.

Formato esperado do arquivo recebido:
  login senha dias limite [uuid]

Regras importantes:
- dias <= 0 nunca é sincronizado.
- usuário, senha, limite e UUID são validados antes da execução.
- usuários inválidos/expirados são ignorados e registrados no log.
- o script não executa comandos via shell=True.
- evita execuções simultâneas com lock local.
"""

import fcntl
import json
import logging
import os
import re
import subprocess
import sys
import traceback
from pathlib import Path
from typing import Dict, List, Optional, Tuple

BASE_DIR = Path("/opt/darkapi")
LOG_FILE = BASE_DIR / "sshsync.log"
LOCK_FILE = BASE_DIR / "sshsync.lock"
MAX_LOG_SIZE = 3 * 1024 * 1024
BACKUP_COUNT = 3
PYTHON_PATH = sys.executable or "/usr/bin/python3"

UPDATE_USER = BASE_DIR / "UpdateUser.py"
UPDATE_USER_V2 = BASE_DIR / "UpdateUserV2.py"
V2RAY_CONFIG = Path("/etc/v2ray/config.json")
XRAY_CONFIG = Path("/usr/local/etc/xray/config.json")

LOGIN_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
UUID_RE = re.compile(r"^[a-fA-F0-9]{8}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{4}-?[a-fA-F0-9]{12}$")


def rotate_log() -> None:
    try:
        BASE_DIR.mkdir(parents=True, exist_ok=True)
        if LOG_FILE.exists() and LOG_FILE.stat().st_size >= MAX_LOG_SIZE:
            for i in range(BACKUP_COUNT - 1, 0, -1):
                src = LOG_FILE.with_name(LOG_FILE.name + f".{i}")
                dst = LOG_FILE.with_name(LOG_FILE.name + f".{i + 1}")
                if src.exists():
                    if dst.exists():
                        dst.unlink()
                    src.rename(dst)
            LOG_FILE.rename(LOG_FILE.with_name(LOG_FILE.name + ".1"))
    except Exception:
        pass


def setup_logger() -> None:
    rotate_log()
    logging.basicConfig(
        filename=str(LOG_FILE),
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        force=True,
    )


def log(msg: str, level: str = "info") -> None:
    getattr(logging, level.lower(), logging.info)(msg)


def is_safe_sync_file(path: Path) -> bool:
    """Evita que alguém passe um arquivo sensível do sistema como argumento."""
    try:
        real = path.resolve()
        allowed_roots = [
            BASE_DIR.resolve(),
            (BASE_DIR / "sync_incoming").resolve(),
            Path("/tmp").resolve(),
        ]
        return any(str(real).startswith(str(root) + os.sep) or real == root for root in allowed_roots)
    except Exception:
        return False


def normalize_uuid(value: str) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    if not UUID_RE.match(value):
        return ""
    # Mantém compatibilidade: não força hífens porque os módulos atuais aceitam o valor recebido.
    return value


def parse_positive_int(value: str, minimum: int = 1, maximum: int = 3650) -> Optional[int]:
    try:
        n = int(str(value).strip())
    except Exception:
        return None
    if n < minimum or n > maximum:
        return None
    return n


def valid_text_field(value: str, max_len: int = 128) -> bool:
    if not isinstance(value, str):
        return False
    if value == "" or len(value) > max_len:
        return False
    # O formato do arquivo é separado por espaço; qualquer whitespace quebra a estrutura.
    if re.search(r"[\x00-\x20]", value):
        return False
    return True


def parse_line(line: str, line_no: int) -> Tuple[Optional[Dict[str, str]], str]:
    col = line.split()
    if len(col) < 4:
        return None, f"linha {line_no}: colunas insuficientes"

    login, senha, dias_raw, limite_raw = col[0], col[1], col[2], col[3]
    uuid = normalize_uuid(col[4]) if len(col) >= 5 else ""

    if not LOGIN_RE.match(login):
        return None, f"linha {line_no}: login inválido ({login})"
    if not valid_text_field(senha, 128):
        return None, f"linha {line_no}: senha inválida para {login}"

    dias = parse_positive_int(dias_raw, 1, 3650)
    if dias is None:
        # Aqui fica a regra principal solicitada: expirados/dias zero não sincronizam.
        return None, f"linha {line_no}: usuário {login} ignorado por validade expirada/inválida (dias={dias_raw})"

    limite = parse_positive_int(limite_raw, 1, 100000)
    if limite is None:
        return None, f"linha {line_no}: limite inválido para {login} ({limite_raw})"

    if len(col) >= 5 and uuid == "":
        return None, f"linha {line_no}: UUID inválido para {login}; usuário V2Ray ignorado"

    return {
        "login": login,
        "senha": senha,
        "dias": str(dias),
        "limite": str(limite),
        "uuid": uuid,
    }, ""


def load_valid_users(sync_file: Path) -> Tuple[List[Dict[str, str]], Dict[str, int]]:
    stats = {
        "linhas_lidas": 0,
        "validos": 0,
        "expirados_ou_invalidos": 0,
        "duplicados": 0,
    }

    users_by_login: Dict[str, Dict[str, str]] = {}

    with sync_file.open("r", encoding="utf-8", errors="ignore") as f:
        for line_no, raw in enumerate(f, start=1):
            line = raw.strip()
            if not line:
                continue

            stats["linhas_lidas"] += 1
            user, reason = parse_line(line, line_no)
            if user is None:
                stats["expirados_ou_invalidos"] += 1
                log(f"Ignorado: {reason}", "warning")
                continue

            login = user["login"]
            if login in users_by_login:
                stats["duplicados"] += 1
                # Mantém a versão com maior validade. Se empatar, mantém a última recebida.
                if int(user["dias"]) < int(users_by_login[login]["dias"]):
                    continue
            users_by_login[login] = user

    users = list(users_by_login.values())
    stats["validos"] = len(users)
    return users, stats


def run_command(cmd: List[str], label: str) -> bool:
    try:
        log(f"Executando {label}: {' '.join(cmd)}")
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=120,
            check=False,
        )
        if result.returncode == 0:
            log(f"✔️ {label} concluído")
            return True

        out = (result.stdout or "").strip()
        err = (result.stderr or "").strip()
        log(f"❌ {label} falhou. Código={result.returncode} stdout={out[:400]} stderr={err[:400]}", "error")
        return False
    except subprocess.TimeoutExpired:
        log(f"❌ {label} excedeu o tempo limite", "error")
        return False
    except Exception as e:
        log(f"❌ Erro ao executar {label}: {e}", "error")
        return False


def remove_duplicates_v2ray(path: Path) -> bool:
    if not path.exists():
        return False
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        changed = False
        inbounds = data.get("inbounds", [])
        if inbounds:
            settings = inbounds[0].setdefault("settings", {})
            clients = settings.get("clients", [])
            seen_ids, seen_emails, clean = set(), set(), []
            for client in clients:
                cid = client.get("id")
                email = client.get("email")
                key = (cid, email)
                if cid in seen_ids or email in seen_emails:
                    changed = True
                    continue
                seen_ids.add(cid)
                seen_emails.add(email)
                clean.append(client)
            settings["clients"] = clean

        if changed:
            with path.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.chmod(path, 0o644)
            log("Duplicatas V2Ray removidas.")
        return changed
    except Exception as e:
        log(f"Erro ao limpar duplicatas V2Ray: {e}", "error")
        return False


def remove_duplicates_xray(path: Path) -> bool:
    if not path.exists():
        return False
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        changed = False
        for inbound in data.get("inbounds", []):
            if inbound.get("tag") != "inbound-sshplus":
                continue
            settings = inbound.setdefault("settings", {})
            clients = settings.get("clients", [])
            seen_ids, seen_emails, clean = set(), set(), []
            for client in clients:
                cid = client.get("id")
                email = client.get("email")
                if cid in seen_ids or email in seen_emails:
                    changed = True
                    continue
                seen_ids.add(cid)
                seen_emails.add(email)
                clean.append(client)
            settings["clients"] = clean

        if changed:
            with path.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.chmod(path, 0o644)
            log("Duplicatas XRay removidas.")
        return changed
    except Exception as e:
        log(f"Erro ao limpar duplicatas XRay: {e}", "error")
        return False


def restart_service(service: str, config_path: Path) -> None:
    if not config_path.exists():
        return
    try:
        active = subprocess.run(["systemctl", "is-active", "--quiet", service]).returncode == 0
        action = "restart" if active else "start"
        subprocess.run(["systemctl", action, service], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        log(f"Serviço {service} {action} executado com sucesso.")
    except Exception as e:
        log(f"Erro ao reiniciar/iniciar {service}: {e}", "error")


def restart_proxy_services(used_v2ray: bool) -> None:
    if not used_v2ray:
        log("Nenhum usuário V2Ray/XRay atualizado; reinício de v2ray/xray não é necessário.")
        return
    remove_duplicates_v2ray(V2RAY_CONFIG)
    remove_duplicates_xray(XRAY_CONFIG)
    restart_service("v2ray", V2RAY_CONFIG)
    restart_service("xray", XRAY_CONFIG)


def main() -> int:
    setup_logger()
    log("==== INÍCIO DA SINCRONIZAÇÃO SSHSYNC ====")

    BASE_DIR.mkdir(parents=True, exist_ok=True)
    lock_handle = LOCK_FILE.open("w")
    try:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        log("Outra execução do sshsync.py já está em andamento. Saindo para evitar duplicidade.", "warning")
        print("busy")
        return 0

    try:
        if len(sys.argv) < 2:
            log("Arquivo de sincronização não informado.", "error")
            print("error")
            return 1

        sync_file = Path(sys.argv[1])
        if not sync_file.exists() or not sync_file.is_file():
            log(f"Arquivo de sincronização inexistente: {sync_file}", "error")
            print("error")
            return 1

        if not is_safe_sync_file(sync_file):
            log(f"Arquivo de sincronização fora de caminho permitido: {sync_file}", "error")
            print("error")
            return 1

        if not UPDATE_USER.exists():
            log(f"UpdateUser.py não encontrado em {UPDATE_USER}", "error")
            print("error")
            return 1

        if not UPDATE_USER_V2.exists():
            log(f"UpdateUserV2.py não encontrado em {UPDATE_USER_V2}", "error")
            print("error")
            return 1

        users, stats = load_valid_users(sync_file)
        log(
            "Resumo do arquivo: "
            f"linhas={stats['linhas_lidas']} validos={stats['validos']} "
            f"ignorados={stats['expirados_ou_invalidos']} duplicados={stats['duplicados']}"
        )

        # Sempre remove o arquivo recebido para não reprocessar dados antigos.
        try:
            sync_file.unlink()
        except Exception as e:
            log(f"Aviso: não foi possível remover arquivo temporário {sync_file}: {e}", "warning")

        if not users:
            log("Nenhum usuário ativo e válido para sincronizar. Nada será aplicado na VPS.", "warning")
            print("nenhum_usuario_valido")
            return 0

        ok_count = 0
        fail_count = 0
        v2_count = 0

        for user in users:
            if user["uuid"]:
                v2_count += 1
                ok = run_command(
                    [PYTHON_PATH, str(UPDATE_USER_V2), user["uuid"], user["login"], user["senha"], user["dias"], user["limite"]],
                    f"UpdateUserV2({user['login']})",
                )
            else:
                ok = run_command(
                    [PYTHON_PATH, str(UPDATE_USER), user["login"], user["senha"], user["dias"], user["limite"]],
                    f"UpdateUser({user['login']})",
                )

            if ok:
                ok_count += 1
            else:
                fail_count += 1

        restart_proxy_services(v2_count > 0)

        log(f"Usuários aplicados com sucesso: {ok_count}")
        log(f"Usuários com falha: {fail_count}")
        log(f"Usuários V2Ray/XRay aplicados: {v2_count}")
        log("==== FIM DA SINCRONIZAÇÃO SSHSYNC ====\n")

        if fail_count > 0 and ok_count == 0:
            print("error")
            return 1

        print("comandoenviadocomsucesso")
        return 0

    except Exception as e:
        log(f"Erro geral: {e}\n{traceback.format_exc()}", "error")
        try:
            if len(sys.argv) >= 2:
                sync_file = Path(sys.argv[1])
                if sync_file.exists() and is_safe_sync_file(sync_file):
                    sync_file.unlink()
        except Exception:
            pass
        print("error")
        return 1
    finally:
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
            lock_handle.close()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
